package com.yyr.dao;

import com.yyr.bean.User;
import com.yyr.mapping.UserMapper;
import com.yyr.utils.MybatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

/**
 * Created by yyr on 15-11-27.
 */
public class UserDao {
    private SqlSessionFactory sessionFactory = MybatisUtil.getInstance();
    //创建能执行映射文件中sql的sqlSession
    SqlSession session = sessionFactory.openSession();
    UserMapper userMapper = session.getMapper(UserMapper.class);
    User user= new User();

    public User find(String username, String userpsw) {
        try {
            user.setUsername(username);
            user.setUserpsw(userpsw);
            user = userMapper.find(user);
        } finally {
            session.close();
            return user;
        }
    }
}