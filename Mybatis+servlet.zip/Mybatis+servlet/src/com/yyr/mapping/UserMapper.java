package com.yyr.mapping;

import com.yyr.bean.User;

/**
 * Created by yyr on 15-11-27.
 */
public interface UserMapper {
    /**
     * 查找(单件)
     **/
    User find(User user);

}