package com.yyr.servlet;

import com.yyr.bean.User;
import com.yyr.dao.UserDao;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Created by yyr on 15-11-25.
 */
@WebServlet("/LoginTestServlet")
public class Servlet extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID = 1L;

    public Servlet() {
        super();

    }

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        response.setContentType("text/heml;charset=gb2312");
        request.setCharacterEncoding("gb2312");

        String result = "";

        String username = request.getParameter("username");
        String psw = request.getParameter("password");

        if (username == "" || username == null || username.length() > 20) {
            try {
                result = "请输入用户名（不能超过20个字符）";
                request.setAttribute("message", result);
                response.sendRedirect("page/index.jsp");
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (psw == "" || psw == null || psw.length() > 20) {
            try {
                result = "请输入密码（不能超过20个字符）";
                request.setAttribute("message", result);
                response.sendRedirect("page/index.jsp");
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        UserDao userDao = new UserDao();
        User user = userDao.find(username, psw);

        HttpSession session = request.getSession();
        session.setAttribute("username", username);

        try {
            if (user != null) {
                session.setAttribute("age", String.valueOf(user.getAge()));
                session.setAttribute("sex", String.valueOf(user.getSex()));
                session.setAttribute("weight", String.valueOf(user.getWeight()));
                response.sendRedirect("page/success.jsp");
                return;
            } else {
                session.setAttribute("message", "用户名或密码不匹配。");
                response.sendRedirect("page/fail.jsp");
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doPost(request, response);
    }
}